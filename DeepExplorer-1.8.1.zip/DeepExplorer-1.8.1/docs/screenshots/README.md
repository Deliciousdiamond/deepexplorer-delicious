# Screenshots

Add real screenshots here before publishing the repository:

- `home.png` — homepage with search bar and engine picker
- `ai.png` — AI panel
- `themes.png` — appearance dialog
- `diagnostic.png` — network diagnostic card

Please remove personal information, private API keys, and personal wallpapers before committing screenshots.

Then reference them in the root `README.md`.
