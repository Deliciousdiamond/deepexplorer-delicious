---
name: Bug report
about: Something is broken or visually wrong
title: "[Bug] "
labels: bug
assignees: ""
---

## What happened

<!-- A clear description. -->

## Steps to reproduce

1.
2.
3.

## Expected behavior

## Device / build

- DeepExplorer version (Settings footer):
- Android version:
- WebView version (if known):
- Device model:

## Logs / screenshots

<!-- Remove API keys, personal URLs and private screenshots first. -->
