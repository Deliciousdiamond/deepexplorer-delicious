---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
assignees: ""
---

## Problem

<!-- What is annoying or missing? -->

## Proposed solution

## Alternatives considered

## Scope check

- [ ] This does not require account login, cloud sync or an extension system.
- [ ] I understand the project intentionally has no Gradle/AndroidX dependency.
