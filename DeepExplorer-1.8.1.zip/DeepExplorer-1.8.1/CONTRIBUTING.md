# Contributing to DeepExplorer

Thanks for taking a look. This is a small framework-only Android project, so the
contribution process is intentionally simple.

## Before you start

- Use GitHub Issues for bug reports and feature proposals.
- Security issues: **do not open a public issue**; follow [SECURITY.md](SECURITY.md).
- Never commit:
  - DeepSeek API keys (`sk-...`)
  - signing keystores (`.jks`, `.keystore`) or passwords
  - local SDKs (`sdk/`), signing output (`build/`), `.env` files
  - personal screenshots with private data

## Workflow

1. Fork the repository.
2. Create a branch:

   ```bash
   git checkout -b fix/short-description
   ```

3. Build and test:

   ```bash
   export ANDROID_JAR="/path/to/android-29/android.jar"
   export KEYSTORE_PASS="..."
   ./build.sh
   ```

4. Keep changes focused; avoid unrelated formatting churn.
5. Commit with a clear message:

   ```text
   fix: keep original URL on local error page
   feat: add keyboard shortcut for find bar
   docs: clarify API 29 build requirements
   ```

6. Push and open a Pull Request against `main`.

## Code style

- Java 8 syntax, no AndroidX, no Gradle, no Kotlin.
- Prefer framework APIs already used by the project.
- Keep animation work on `alpha` / `translation` / `scale`; avoid layout changes
  per frame.
- Keep JavaScript in `app/assets/` free of timer loops.
- New user-visible strings go in `app/res/values/strings.xml`; avoid hardcoded
  Chinese/English strings in Java.
- Preserve the existing Nightly-inspired visual language: rounded glass panels,
  restrained color, no oversized decorative elements.
- If you add a third-party asset/library, add its license to
  `THIRD_PARTY_NOTICES.md`. The project currently has a strict no-dependency
  policy; discuss first if a change requires a new library.

## Testing

There is no automated test suite yet. Before opening a PR:

- Build with `./build.sh`.
- Install on a device/emulator (Android 10+).
- Check:
  - web search, tabs, back/forward
  - AI panel and model switch (with a valid key)
  - theme/font switcher
  - bookmark, find-in-page, desktop site
  - offline banner and network diagnostic
  - local error page and retry

## PR checklist

- [ ] `./build.sh` passes
- [ ] No API keys, keystores, SDK folders or build output added
- [ ] `README.md` / `CHANGELOG.md` updated if behavior changed
- [ ] Screenshots attached for UI changes (with no private data)
