# Security policy

## Supported versions

Security fixes are applied to the current `1.6.x` line. Older builds are not
maintained.

## Reporting a vulnerability

Please **do not open a public issue** for security problems.

Use GitHub's private vulnerability reporting:

1. Open the repository's **Security** tab.
2. Choose **Report a vulnerability**.
3. Include:
   - affected version
   - Android / WebView version
   - steps to reproduce
   - impact
   - a minimal proof of concept, if safe

Do not include real API keys, passwords, personal browsing URLs or signing
material. If a key leaked, revoke/rotate it immediately.

## Secrets in this repository

- DeepSeek API keys are entered by the user at runtime and stored in local
  `SharedPreferences`; the repository contains none.
- Release signing keys are intentionally excluded by `.gitignore` and must stay
  local. A leaked signing key compromises future updates.
- `.env`, `keystore/`, `*.jks`, `*.keystore` are ignored.

## Scope

This is a local Android browser shell. Typical in-scope issues include:

- unexpected network requests or data leakage
- unsafe `addJavascriptInterface` exposure beyond the bundled local pages
- local file / content URI access outside the chosen wallpaper
- denial of service via malicious page → WebView crash (please report with a
  reproducible URL, but avoid testing on third-party sites without permission)

Out of scope: vulnerabilities in the user's system WebView, DeepSeek API,
individual websites, and social engineering.
