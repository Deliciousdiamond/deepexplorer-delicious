# 把 DeepExplorer 发布到 GitHub（新手版）

这份指南假设你**没有用过 Git**。按顺序做即可。全程不要把 API Key、签名文件
（`.jks` / `.keystore`）或密码发到聊天、Issue、提交记录里。

> **当前工作区已经完成：**
> `git init -b main`、首次 commit、`origin` 指向
> `https://github.com/Deliciousdiamond/DeepExplorer.git`。
> 如果你直接使用这个文件夹，可以跳过第 4 节的初始化/提交，从第 5 节创建 PAT
> 开始，然后执行 `git push -u origin main`。
> 如果你把源码复制到别处、没有 `.git`，再按第 3、4 节重新初始化。

---

## 0. 先理解三个东西

- **Git**：在你电脑/手机上记录项目版本的本地工具。
- **GitHub**：托管 Git 仓库的网站。
- **仓库（Repository）**：一个项目文件夹在 GitHub 上的副本。

你的项目已经准备好：

- `.gitignore` 会排除 `build/`、`sdk/`、`*.jks`、`keystore/`、`.env*`
- `LICENSE` 是 MIT
- `README.md` 是项目介绍
- `BUILDING.md` 是构建说明
- `GITHUB_GUIDE.md` 就是本文件

---

## 1. 在 GitHub 上新建仓库

1. 登录 <https://github.com>。
2. 右上角 `+` → **New repository**。
3. 填写：
   - **Repository name**: `DeepExplorer`
   - **Description**: `Minimal Android WebView browser with a built-in DeepSeek assistant`
   - **Public** 选中
4. **不要**勾选 “Add a README file”“Add .gitignore”“Choose a license”——这些项目里已经有了。
5. 点 **Create repository**。

创建后会看到一个空仓库页面，里面有仓库地址：

```text
https://github.com/Deliciousdiamond/DeepExplorer.git
```

---

## 2. 安装 Git

### Windows

1. 打开 <https://git-scm.com/download/win> 下载安装。
2. 安装完成后打开 **Git Bash**，输入：

```bash
git --version
```

### macOS

打开终端，输入：

```bash
git --version
```

如果没有，按提示安装 Xcode Command Line Tools，或从 <https://git-scm.com/download/mac> 安装。

### Android / Termux

```bash
pkg update
pkg install git
git --version
```

### 这台 Android 设备（推荐：直接用 DSH 终端）

当前项目已经安装好 Git、完成首次提交并配置好 `origin`，不需要再 `git init`。
在 DSH 里打开终端，直接执行：

```bash
cd /data/data/com.dsh.webview/files/workspace/deepseek-harness/default-workspace/deepexplorer
git status
git push -u origin main
```

用户名填 `Deliciousdiamond`，密码粘贴 PAT。不要把 PAT 发到聊天或写进文件。

> 独立安装的 Termux 不能直接读这个应用私有目录。优先用 DSH 自带终端；
> 如果必须用外部 Termux，只导出**已被 Git 跟踪的源码**，不要把
> `sdk/`、`build/`、`.jks` 或整个项目目录复制到公共存储。

---

## 3. 配置 Git 身份

只需设置一次。把邮箱换成 GitHub 账号设置里给你的 **noreply** 邮箱，能保护隐私：

1. GitHub → 右上角头像 → **Settings**
2. 左侧 **Emails**
3. 找到 **Keep my email addresses private**，复制类似
   `12345678+Deliciousdiamond@users.noreply.github.com` 的地址

然后在项目目录执行：

```bash
git config --global user.name "Deliciousdiamond"
git config --global user.email "你的noreply邮箱"
```

检查：

```bash
git config --global --list
```

---

## 4. 第一次提交

在项目根目录（有 `README.md` 和 `build.sh` 的那一层）执行：

```bash
git init
git add .
git status
```

**关键一步：检查有没有敏感文件。** 执行：

```bash
git ls-files | grep -E '(^sdk/|^build/|\.jks$|\.keystore$|^keystore/|^\.env)'
```

这条命令**应该没有任何输出**。如果列出了 `.jks`、`sdk/` 或 `build/`，
先停止，检查 `.gitignore`，不要继续提交。

然后提交：

```bash
git commit -m "Initial open-source release of DeepExplorer 1.8.0"
git branch -M main
```

---

## 5. 连接 GitHub

```bash
git remote add origin https://github.com/Deliciousdiamond/DeepExplorer.git
git remote -v
```

`remote -v` 应显示 `origin` 指向你的仓库。

### 5.1 创建 Personal Access Token（PAT）

GitHub 现在不接受账号密码作为 Git 密码，需要用 token。

1. GitHub → 头像 → **Settings**
2. 左侧最下 **Developer settings**
3. **Personal access tokens** → **Tokens (classic)**
4. **Generate new token (classic)**
5. Note 填 `DeepExplorer push`
6. Expiration 选一个你能接受的时间（例如 30 天）
7. 勾选 **repo**
8. **Generate token**
9. 复制 `ghp_...` 开头的 token

> 这个 token 只显示一次。不要把它写进文件、README、Issue 或聊天。
> 如果泄露，立刻在同一页面 Revoke。

### 5.2 推送

```bash
git push -u origin main
```

终端会提示：

- **Username**: 输入 `Deliciousdiamond`
- **Password**: 粘贴 token（输入时不会显示字符，粘贴后直接回车）

推送成功后刷新 GitHub 仓库页面，应该能看到 README、源码和 LICENSE。

---

## 6. 发布 APK（Releases）

APK **不提交进 Git 仓库**（`.gitignore` 已排除），而是作为 Release 附件上传。

### 6.1 先打 tag

```bash
git tag -a v1.8.0 -m "DeepExplorer 1.8.0"
git push origin v1.8.0
```

### 6.2 在 GitHub 创建 Release

1. 仓库首页右侧 **Releases** → **Draft a new release**
2. **Choose a tag** 选 `v1.8.0`
3. **Release title**：`DeepExplorer 1.8.0`
4. 写更新说明（可以从 `CHANGELOG.md` 复制）
5. 在 **Attach binaries** 上传：
   - `build/DeepExplorer.apk`
6. 点 **Publish release**

以后发版重复：改版本号 → 构建 → 提交 → `git tag vX.Y.Z` → push tag → 新 Release。

---

## 7. 推送后检查仓库

1. 首页 README 是否正常显示。
2. **Insights → Contributors** 是否有你的提交。
3. **Settings → General** 填 Description。
4. **Topics** 建议：
   ```text
   android webview browser deepseek java material3 firefox-nightly no-gradle
   ```
5. **Settings → Pages** 不需要开启。
6. 确认仓库里没有：
   - `sdk/`
   - `build/`
   - `*.jks` / `*.keystore`
   - API Key
   - 个人截图

---

## 8. 如果推送失败

### `Authentication failed`

- 确认 Password 用的是 PAT，不是 GitHub 登录密码。
- 确认 token 勾选了 `repo`。
- token 过期就重新生成。

### `remote origin already exists`

```bash
git remote remove origin
git remote add origin https://github.com/Deliciousdiamond/DeepExplorer.git
```

### `updates were rejected`

如果 GitHub 仓库创建时勾选了 README，会先有一个远程提交。可以：

```bash
git pull --rebase origin main
git push -u origin main
```

### 提交了不该提交的文件

如果还没 push：

```bash
git rm --cached path/to/file
git commit --amend
```

如果已经 push，仅删除文件不够，历史里仍能找回。请立刻：

1. 撤销/更换泄露的 token 或签名密钥
2. 用 `git filter-repo` 或 GitHub 的 secret scanning 清理历史
3. 重新提交

签名密钥一旦泄露，最安全的做法是生成新密钥并发布新 APK；旧密钥不能再用于正式发布。

---

## 9. 更简单的替代方案

如果你不想敲 Git 命令：

- **GitHub Desktop**（Windows/macOS）：安装后 `Add local repository`，选择项目，
  然后 `Publish repository`。不需要手动配置 remote。
- **GitHub 网页上传**：只能作为临时方案。上传时不要拖入 `sdk/`、`build/`、
  `.jks`；网页上传不会自动应用 `.gitignore`，容易误传。

---

## 10. 发布前最后清单

- [ ] 设置底部版本号是 `1.8.0`
- [ ] README 截图已补充且没有个人信息
- [ ] API Key 没有出现在仓库任何文件
- [ ] `git ls-files | grep -E '(sdk/|build/|\.jks$|\.keystore$|keystore/|\.env)'` 无输出
- [ ] `LICENSE` 年份/署名正确
- [ ] Release 上传了 `DeepExplorer.apk`
- [ ] 在真机上重新安装 Release APK，确认能打开
