package com.deliciousdiamond.deepexplorer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Minimal DeepSeek chat-completions client with SSE streaming. */
public final class AiClient {
    private static final String ENDPOINT = "https://api.deepseek.com/chat/completions";

    public interface Listener {
        void onStart();

        void onChunk(String text);

        void onDone(String fullText);

        void onError(String message);
    }

    private volatile boolean cancelled;
    private volatile HttpURLConnection connection;
    private volatile InputStream activeStream;
    private Thread thread;

    public void stream(final String apiKey, final String model, final JSONArray messages, final Listener listener) {
        cancel();
        cancelled = false;
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                InputStream input = null;
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) {
                        listener.onError("请先在设置中填写 DeepSeek API Key");
                        return;
                    }
                    JSONObject body = new JSONObject();
                    String chosenModel = model == null || model.isEmpty() ? "deepseek-chat" : model;
                    body.put("model", chosenModel);
                    body.put("messages", messages);
                    body.put("stream", true);
                    if (!"deepseek-reasoner".equals(chosenModel)) body.put("temperature", 0.7);
                    body.put("max_tokens", 2048);
                    byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);

                    conn = (HttpURLConnection) new URL(ENDPOINT).openConnection();
                    connection = conn;
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(120000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    conn.setRequestProperty("Accept", "text/event-stream");
                    conn.setRequestProperty("User-Agent", "DeepExplorer/1.0 Android");

                    OutputStream out = conn.getOutputStream();
                    out.write(payload);
                    out.flush();
                    out.close();

                    int code = conn.getResponseCode();
                    if (code != 200) {
                        String detail = readLimited(conn.getErrorStream(), 4096);
                        if (!cancelled) listener.onError(friendlyError(code, detail));
                        return;
                    }

                    input = conn.getInputStream();
                    activeStream = input;
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
                    listener.onStart();

                    StringBuilder full = new StringBuilder();
                    String line;
                    while (!cancelled && (line = reader.readLine()) != null) {
                        line = line.trim();
                        if (!line.startsWith("data:")) continue;
                        String data = line.substring(5).trim();
                        if (data.isEmpty()) continue;
                        if ("[DONE]".equals(data)) break;
                        try {
                            JSONObject chunk = new JSONObject(data);
                            JSONArray choices = chunk.optJSONArray("choices");
                            if (choices == null || choices.length() == 0) continue;
                            JSONObject choice = choices.optJSONObject(0);
                            if (choice == null) continue;
                            JSONObject delta = choice.optJSONObject("delta");
                            if (delta == null || delta.isNull("content")) continue;
                            String text = delta.optString("content", "");
                            if (!text.isEmpty()) {
                                full.append(text);
                                if (!cancelled) listener.onChunk(text);
                            }
                        } catch (Exception ignored) {
                            // Ignore keep-alives or a malformed SSE line; the next line is independent.
                        }
                    }
                    if (!cancelled) listener.onDone(full.toString());
                } catch (Throwable t) {
                    if (!cancelled) listener.onError(networkMessage(t));
                } finally {
                    if (input != null) {
                        try { input.close(); } catch (Throwable ignored) { }
                    }
                    if (conn != null) {
                        try { conn.disconnect(); } catch (Throwable ignored) { }
                    }
                    // Only clear the shared fields if they still belong to this request:
                    // a newer stream may already have replaced them after cancel().
                    if (connection == conn) connection = null;
                    if (activeStream == input) activeStream = null;
                }
            }
        }, "deepseek-sse");
        thread.setDaemon(true);
        thread.start();
    }

    public void cancel() {
        cancelled = true;
        try {
            if (activeStream != null) activeStream.close();
        } catch (Throwable ignored) {
        }
        try {
            if (connection != null) connection.disconnect();
        } catch (Throwable ignored) {
        }
        Thread t = thread;
        if (t != null) t.interrupt();
    }

    public boolean isStreaming() {
        Thread t = thread;
        return t != null && t.isAlive() && !cancelled;
    }

    private static String networkMessage(Throwable t) {
        String message = t == null ? "" : String.valueOf(t.getMessage());
        if (message.toLowerCase().contains("timeout")) return "请求超时，请稍后再试。";
        return "网络连接失败，请检查网络后重试。";
    }

    private static String friendlyError(int code, String detail) {
        if (code == 401) return "API Key 无效或已过期。";
        if (code == 402) return "API 余额不足。";
        if (code == 429) return "请求过于频繁，请稍后再试。";
        String fromBody = null;
        try {
            JSONObject object = new JSONObject(detail);
            JSONObject error = object.optJSONObject("error");
            if (error != null) fromBody = error.optString("message", null);
        } catch (Exception ignored) {
        }
        if (fromBody != null && !fromBody.isEmpty()) return "请求失败：" + fromBody;
        return "请求失败（HTTP " + code + "）";
    }

    private static String readLimited(InputStream input, int max) {
        if (input == null) return "";
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int n;
            int total = 0;
            while (total < max) {
                n = input.read(buffer, 0, Math.min(buffer.length, max - total));
                if (n <= 0) break;
                out.write(buffer, 0, n);
                total += n;
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        } finally {
            try { input.close(); } catch (IOException ignored) { }
        }
    }
}
