# 深探 / DeepExplorer 1.8.1 — 项目文件夹

这是从 Git 仓库 HEAD（`21a47db`）导出的**干净源码快照**，用于备份、分享或上传 GitHub。

## 内容

- `app/`：Android 源码、资源、HTML/AI 页面
- `docs/`：图标和截图占位
- `build.sh`：无 Gradle 构建脚本
- `BUILDING.md`：构建说明
- `GITHUB_GUIDE.md`：GitHub 上传教程
- `README.md` / `LICENSE` / `CHANGELOG.md`
- `dist/DeepExplorer-1.8.1.apk`：已签名安装包
- `dist/SHA256SUMS.txt`：APK 校验值
- `.gitignore` / `.gitattributes`：Git 规则

## 1.8.1 改了什么

见 `CHANGELOG.md`。要点：主页壁纸后台解码并按屏幕像素降采样、AI 历史裁剪后首条必须为
user、模型输出链接/图片协议白名单、修复 SSE 取消竞态、下载轮询在后台暂停、错误页改用
中立 origin 且 retry 只在错误页可见时生效、退出时关闭下载弹窗。

## 故意不包含

- `deepexplorer.jks` / 任何签名密钥
- `sdk/` 本地 Android SDK
- `build/` 构建中间产物和旧 APK
- `.git/` 历史目录
- API Key（运行 App 后自己填写）

## 上传 GitHub

这个文件夹**没有 `.git`**，是一个干净的源码快照。有两种做法：

1. 直接使用原来的 `deepexplorer` 项目目录（已有提交历史和 `origin`）：
   ```bash
   cd /data/data/com.dsh.webview/files/workspace/deepseek-harness/default-workspace/deepexplorer
   git push -u origin main
   ```

2. 只使用这个文件夹时，重新初始化：
   ```bash
   cd /sdcard/Download/DeepExplorer-1.8.1
   git init -b main
   git add .
   git commit -m "DeepExplorer 1.8.1"
   git remote add origin https://github.com/Deliciousdiamond/DeepExplorer.git
   git push -u origin main
   ```

   `.gitignore` 已排除 `*.apk`，所以 `dist/` 里的 APK 不会被 Git 跟踪；发布时把 APK 上传到 GitHub Releases。

## 安装 APK

`dist/DeepExplorer-1.8.1.apk`

包名：`com.deliciousdiamond.deepexplorer`  
应用名：深探  
版本：versionCode 19 / versionName 1.8.1

签名与 1.8.0 是同一把密钥（证书 SHA-256 `f61f457d675f04100b747a932268529c7e67790fd1568be42472af59dd2a89f7`），
所以可以直接覆盖安装，不需要先卸载；卸载会清掉书签、设置和 API Key。
