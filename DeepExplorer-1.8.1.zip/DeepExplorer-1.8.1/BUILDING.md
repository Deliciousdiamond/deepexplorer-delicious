# Building DeepExplorer

DeepExplorer deliberately avoids Gradle. The APK is assembled with the Android
SDK command-line tools, so builds are small and reproducible without Android
Studio.

## What you need

| Tool | Why |
|---|---|
| JDK 8+ (`javac`, `keytool`) | compile Java and create a signing key |
| Android SDK Build-Tools | `aapt`, `d8`, `zipalign`, `apksigner` |
| Android Platform 29 `android.jar` | compile/runtime classpath (`targetSdk 29`) |
| `zip` | add `classes.dex` to the APK |
| `bash` | run `build.sh` |

The project does **not** include the Android SDK or a signing key.
`build/`, `sdk/`, `*.jks`, `*.keystore`, `keystore/` and `.env*` are ignored by
Git; keep it that way.

## 1. Install build tools

### Linux / macOS

Install a JDK and the Android command-line build-tools, then make sure these
commands are on `PATH`:

```bash
aapt d8 zipalign apksigner javac keytool zip
```

The SDK layout normally looks like:

```text
~/Android/Sdk/
├── build-tools/35.0.0/
└── platforms/android-29/android.jar
```

### Android / Termux

Install a JDK, `zip` and the Android build-tools in your Termux environment, or
use an existing SDK. Then point `ANDROID_JAR` at the platform jar. The build
script itself is plain bash, so it works on-device as well as on a desktop.

## 2. Create a signing key (once)

**Never commit the generated key.** It is the update identity of your app.

```bash
export KEYSTORE_PASS='choose-a-strong-password'
./scripts/generate-keystore.sh
```

This creates `keystore/release.jks` (ignored by Git) with alias `release`.

If you already have a key, use it instead:

```bash
export KEYSTORE="/path/to/your.jks"
export KEY_ALIAS="your-alias"
export KEYSTORE_PASS="..."
export KEY_PASS="$KEYSTORE_PASS"
```

## 3. Build

```bash
export ANDROID_JAR="$HOME/Android/Sdk/platforms/android-29/android.jar"
export KEYSTORE="$PWD/keystore/release.jks"
export KEY_ALIAS="release"
export KEYSTORE_PASS="choose-a-strong-password"

./build.sh
```

Output:

```text
build/DeepExplorer.apk
```

To copy it somewhere after building:

```bash
COPY_TO="$HOME/DeepExplorer.apk" ./build.sh
```

## Environment variables

| Variable | Required | Default |
|---|---|---|
| `KEYSTORE_PASS` | yes | — |
| `ANDROID_JAR` | recommended | `$ANDROID_HOME/platforms/android-29/android.jar` |
| `KEYSTORE` | no | `keystore/release.jks` |
| `KEY_ALIAS` | no | `release` |
| `KEY_PASS` | no | same as `KEYSTORE_PASS` |
| `OUT` | no | `build/DeepExplorer.apk` |
| `COPY_TO` | no | unset |

## 4. Install

```bash
adb install -r build/DeepExplorer.apk
```

Or copy the APK to the phone and open it (allow “install unknown apps” for the
file manager/browser).

The app is signed with your key. If you previously installed an APK signed by a
different key, uninstall the old app first; Android will reject the update.

## Troubleshooting

### `android.jar not found`

Set `ANDROID_JAR` explicitly:

```bash
export ANDROID_JAR="/path/to/Android/Sdk/platforms/android-29/android.jar"
```

### `aapt: command not found`

Add the build-tools directory to `PATH`:

```bash
export PATH="$HOME/Android/Sdk/build-tools/35.0.0:$PATH"
```

### `Failed to load signer` / `keystore not found`

Check that `KEYSTORE` points to the `.jks` file, and that `KEYSTORE_PASS` is
correct. Do not put passwords in `build.sh` or commit them.

### `java.lang.UnsupportedClassVersionError`

`javac`/`d8` and the JDK must be compatible. Use a current JDK (17 is fine) and
current Android build-tools.

### APK installs but app crashes on launch

Check logcat:

```bash
adb logcat | grep -E 'AndroidRuntime|DeepExplorer'
```

Please include the crash stack and Android/WebView version in a bug report, but
remove API keys and personal URLs first.

## Why no Gradle?

The app uses only framework Android APIs, no AndroidX, no Kotlin, no resources
from libraries. A five-stage `aapt`/`javac`/`d8` pipeline is enough and keeps the
repository readable. If you add AndroidX or Material Components, migrate to a
Gradle project rather than trying to vendor AARs manually.
