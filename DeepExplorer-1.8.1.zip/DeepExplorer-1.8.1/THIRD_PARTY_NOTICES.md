# Third-party notices

## marked

`app/assets/ai.html` embeds **marked v4.3.0** inline.

- Project: https://github.com/markedjs/marked
- License: MIT
- Copyright: 2011-2023, Christopher Jeffrey

The inlined script retains its upstream license header.
